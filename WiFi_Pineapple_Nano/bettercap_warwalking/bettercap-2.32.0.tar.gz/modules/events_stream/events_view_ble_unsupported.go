// +build windows

package events_stream

import (
	"io"
	"github.com/bettercap/bettercap/session"
)

func (mod *EventsStream) viewBLEEvent(output io.Writer, e session.Event) {

}
